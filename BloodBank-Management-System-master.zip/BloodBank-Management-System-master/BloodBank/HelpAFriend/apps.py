from django.apps import AppConfig


class HelpafriendConfig(AppConfig):
    name = 'HelpAFriend'
