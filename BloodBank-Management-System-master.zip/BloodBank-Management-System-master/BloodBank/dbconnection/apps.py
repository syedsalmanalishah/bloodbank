from django.apps import AppConfig


class DbconnectionConfig(AppConfig):
    name = 'dbconnection'
